import "dotenv/config";
import { REST, Routes } from "discord.js";
import { builders } from "./commands.js";

if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) {
  console.error("Missing DISCORD_TOKEN or CLIENT_ID in .env");
  process.exit(1);
}

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
const body = builders.map(c => c.data.toJSON());

try {
  if (process.env.GUILD_ID) {
    await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), { body });
    console.log(`Registered ${body.length} commands to guild ${process.env.GUILD_ID}.`);
  } else {
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body });
    console.log(`Registered ${body.length} global commands. Global propagation can take some time.`);
  }
} catch (err) {
  console.error(err);
  process.exit(1);
}
